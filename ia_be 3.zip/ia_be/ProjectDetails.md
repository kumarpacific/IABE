# Project Details — Enterprise Spring Boot App

## Purpose

This document describes the project structure, runtime configuration, security model, integration points (Azure AD, Oracle), encryption model, and practical guidance for extending the skeleton into a production-ready service.

## High-level architecture

- Spring Boot 3 application (Java 17)
- Web layer: Spring MVC controllers + Thymeleaf for simple UI
- Security: Spring Security with OAuth2 client (Azure AD SSO) configured via `application.yml`
- Filters: custom `ApiRequestFilter` for request enrichment, ISD signature verification, and security headers
- DB integration: Spring JdbcTemplate + `StoredProcedureExecutor` for invoking Oracle stored procedures and returning result sets
- Crypto: centralized `CryptoUtil` providing AES-GCM encrypt/decrypt and HMAC-SHA256 helpers
- Logging: Log4j2 via Spring Boot starter

## Project layout (key files)

- `pom.xml` — Maven build and dependencies
- `src/main/java/com/example/enterpriseapp/EnterpriseAppApplication.java` — Spring Boot entry point
- `config/SecurityConfig.java` — security filter chain + OAuth2 login
- `security/ApiRequestFilter.java` — request enrichment, ISD check, security headers
- `util/CryptoUtil.java` — encryption/hmac utilities
- `db/StoredProcedureExecutor.java` — generic stored-proc executor
- `service/ProcedureService.java` — service wrapper for executor
- `controller/ProcedureController.java` — endpoint which calls stored proc and renders view
- `src/main/resources/application.yml` — runtime configuration (Azure, datasource, logging)
- `src/main/resources/templates/*.html` — Thymeleaf templates

Read through each class in `src/main/java` for implementation notes and inline TODOs.

## Configuration and environment variables

Primary configuration lives in `src/main/resources/application.yml`. Replace placeholders before running.

Environment variables (recommended):
- `APP_ENC_KEY_BASE64` — base64-encoded AES key (256-bit recommended). Used by `CryptoUtil` for AES-GCM decrypt/encrypt.
- `ISD_SHARED_KEY` — shared secret used to generate/verify HMAC signatures for ISD checks.

Datasource (example in application.yml):
- `spring.datasource.url` — JDBC URL for Oracle (thin driver)
- `spring.datasource.username` / `.password`

OAuth2 / Azure AD:
- Populate `spring.security.oauth2.client.registration.azure.client-id` and `.client-secret`.
- Set correct tenant endpoints in `spring.security.oauth2.client.provider.azure.*` or use Spring Boot's Azure starter if preferred.

Secrets should be injected from your environment or secret manager in production (do not commit secrets).

## Security model & ISD checks

1. Authentication: OAuth2 login via Azure AD (OIDC). After login, Spring Security creates a session.
2. Authorization: Example uses method-level security enabled; adjust roles/authorities as needed.
3. ISD signature: `ApiRequestFilter` demonstrates HMAC-SHA256 verification using `ISD_SHARED_KEY`. It currently computes HMAC over `METHOD|URI|QUERY` and compares with `X-ISD-Signature` header. Replace or extend to match your exact signing scheme (timestamp, nonce, canonical body hashes, replay protection).
4. Security headers: the filter sets `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, and `Content-Security-Policy`. Tighten CSP to match your UI/asset hosts.

Important: The current ISD and request-decode implementation is a starting point. For production:
- Enforce TLS in front of the service.
- Validate timestamps/nonces to avoid replay attacks.
- Use a robust key management system (KMS / Azure Key Vault) for keys.

## Encryption and request handling

- The project centralizes AES-GCM encryption in `CryptoUtil`.
- For incoming encrypted requests, the controller checks `X-Encoded:true` and manually decrypts payload. Preferable production approach: implement a `ServletRequestWrapper` that replaces the request InputStream with the decrypted bytes so all controllers and filters operate on the decrypted payload transparently.

Encryption tips:
- Use 256-bit AES keys (32 bytes) and base64-encode them for `APP_ENC_KEY_BASE64`.
- Use unique IV/nonce per encryption (current code generates 12-byte random IV) and include it with ciphertext as implemented.

## Stored procedure execution

- `StoredProcedureExecutor` uses `SimpleJdbcCall` and declares an `OUT_CURSOR` as a `SqlReturnResultSet`. It maps rows to a `Map<String,Object>` per row.
- Adjust parameter names, types, and out param names to match your Oracle stored procedure signatures.
- If stored procs return complex object types, implement appropriate RowMapper or convert to domain objects.

Usage pattern:
1. POST to `/callProcedure?name=PROC_NAME` with JSON body of parameters.
2. Controller decodes payload if needed, converts to Map, calls `ProcedureService`.
3. Service delegates to `StoredProcedureExecutor` which returns a Map that may contain `OUT_CURSOR`.

## Templates / UI

- `index.html` provides a simple form to call a stored procedure.
- `atm-log.html` renders rows returned by the stored proc as an HTML table.
- The templates are intentionally minimal. For any production UI, move to a dedicated front-end (React/Angular) or enhance Thymeleaf with static assets, CSRF tokens, and tighter CSP.

## Logging and monitoring

- Log4j2 is included via the Spring Boot starter. Add `log4j2.xml` under `src/main/resources` to configure appenders (console, files, JSON, or centralized collectors).
- Add request/response correlation (the filter writes `X-Correlation-Id` header). Use that in logs for tracing.
- Integrate with Observability: expose Prometheus metrics (Micrometer), distributed tracing (OpenTelemetry / Jaeger), and centralized log aggregation (ELK/EFK, Splunk).

## Running and testing locally

1. Ensure Java 17 and Maven are installed.
2. Set required env vars (see above).
3. Build and run:

```bash
mvn -U clean package
mvn spring-boot:run
```

4. Use curl to call the endpoint; example shown in README.

Unit/integration tests:
- Add JUnit tests for `CryptoUtil` and `StoredProcedureExecutor` (mock DataSource / JdbcTemplate). For controller tests, use MockMvc and mock the service layer.

## Deployment guidance

- Containerize the application (Docker) and run behind an ingress or API gateway that handles TLS and rate limiting.
- Use an externalized configuration provider (Spring Cloud Config, Kubernetes secrets, or environment variables) to avoid committed secrets.
- Use readiness and liveness probes, resource limits, and horizontal autoscaling.
- Use database connection pooling (HikariCP is default in Spring Boot), and tune pool size for your workload.

Sample Dockerfile (starter):

```dockerfile
FROM eclipse-temurin:17-jdk-jammy
ARG JAR_FILE=target/*.jar
COPY ${JAR_FILE} app.jar
ENTRYPOINT ["java","-jar","/app.jar"]
```

## Extending the project — help tips

1. Transparent request decryption: add a `OncePerRequestFilter` early in the chain which reads the raw request body, decrypts it (if marked), and wraps the request with a `HttpServletRequestWrapper` exposing a new InputStream.
2. Response encryption: implement a `HttpServletResponseWrapper` to encrypt response bytes and set `X-Encoded:true` response header when needed.
3. Stronger ISD: include timestamp+nonce in signature, use asymmetric signatures if needed (RSA/ECDSA), and validate with public key. Add replay cache for nonces.
4. Structured logging: configure Log4j2 to output JSON logs with correlation id, user id, request path, and latency.
5. Observability: add Micrometer metrics and export to Prometheus; wire OpenTelemetry for distributed traces.
6. Error handling: centralize with `@ControllerAdvice` to sanitize errors, avoid leaking internal stack traces, and return consistent error payloads (correlation id, error code, message).
7. API docs: add OpenAPI (springdoc-openapi) and secure the docs in non-prod only or behind auth.
8. CI/CD: add GitHub Actions / GitLab CI pipeline to build, test, run static analysis (SpotBugs, Sonar), and publish images to a registry.

## Dynamic DB browser

This project now includes a lightweight dynamic browser to introspect database tables and display rows dynamically:

- `DatabaseIntrospector` (component) lists tables and columns and queries rows safely using `JdbcTemplate`.
- `GenericDataController` exposes:
	- GET `/data/tables` — list available tables
	- GET `/data/table/{name}?limit=100` — view table columns and up to `limit` rows rendered in `dynamic-table.html`

	API (JSON) endpoints:

	- GET `/data/table/{name}/json?limit=100&offset=0&orderBy=COL&asc=true` — returns JSON array of rows for programmatic access

	Configuration:
	- `app.dynamic.hidden-columns` — list of column names to hide globally from dynamic views.
	Advanced configuration and features:

	- `app.dynamic.masked-columns` — list of column names whose values should be masked in the UI (PII masking)
	- `app.dynamic.column-permissions` — map of column name to allowed roles (example: `{ SSN: [ROLE_AUDIT], SALARY: [ROLE_HR] }`). If a column is listed, only users with one of the listed roles will see it.

	Keyset pagination:

	The introspector provides a `getTableRowsAfter(table, orderBy, lastValue, limit, asc)` helper to support keyset (seek) pagination. The UI exposes basic offset/limit controls; for very large tables you should call the JSON API with `lastValue` (value of `orderBy` column from the last row) to fetch the next page efficiently.

	Example keyset request:

	```bash
	curl "http://localhost:8080/data/table/LOG_MASTER/keyset?orderBy=LOG_DATE&lastValue=2026-01-01%2000:00:00&limit=50&asc=false"
	```

Security note: the introspector validates the requested table exists in the schema before issuing a `SELECT *` query. For production, further hardening is recommended (whitelist, column-level permissions).

## Security checklist before production

- Move keys to KMS / Vault and rotate regularly.
- Enforce TLS (HTTPS) and HSTS.
- Harden CSP and security headers.
- Limit exposed endpoints and enable rate limiting at gateway.
- Implement input validation and parameterized calls for all DB interactions (avoid string SQL concatenation).
- Add RBAC and least privilege rules in Azure AD.

## Troubleshooting

- `mvn` not found: install Maven. On macOS: `brew install maven`.
- Oracle JDBC issues: add `ojdbc` to your artifact repository or local maven repo.
- HMAC mismatches: ensure `ISD_SHARED_KEY` is set and both client/server compute identical canonical payload.

## Next recommended improvements (prioritized)

1. Transparent request/response wrappers for encryption.
2. Robust ISD signing with replay protection.
3. Dockerfile + Kubernetes manifests and health probes.
4. Observability (Prometheus + OpenTelemetry) and structured logs.
5. Unit and integration tests for DB executor and security filter.

---

If you want, I can implement any of the recommended improvements (start with the transparent request wrapper or a Dockerfile + k8s manifest). Tell me which one to work on next.
