# Enterprise Spring Boot App (skeleton)

This project is a skeleton for an enterprise-grade Spring Boot application with:

- OAuth2 login (Azure AD) SSO configuration points in `application.yml`
- Central AES-GCM encode/decode utils and HMAC ISD check
- API request filter to enrich requests and enforce ISD signature and security headers
- Stored procedure executor using Spring JdbcTemplate (Oracle)
- Thymeleaf views to display stored-procedure result (ATM log table)
- Logging with Log4j2

Requirements before running:

- Java 17
- Maven
- Oracle JDBC driver available (ojdbc) - the pom includes ojdbc8 runtime, add to your local repo if needed
- Set environment variables for `APP_ENC_KEY_BASE64` (base64 AES key) and `ISD_SHARED_KEY` for HMAC

Run locally:

```bash
mvn -U clean package
mvn spring-boot:run
```

Configuration:

- Edit `src/main/resources/application.yml` to set Azure AD and datasource values.
- The sample expects an out parameter named `OUT_CURSOR` which returns rows.

Security notes:

- The ISD signature check in `ApiRequestFilter` is a placeholder. Replace with your real validation.
- Centralized encode/decode uses AES-GCM with a base64 key in env var `APP_ENC_KEY_BASE64`.
