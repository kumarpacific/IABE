package com.example.enterpriseapp.controller;

import com.example.enterpriseapp.service.ProcedureService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/logs")
public class LogController {
    private final ProcedureService procedureService;

    public LogController(ProcedureService procedureService) {
        this.procedureService = procedureService;
    }

    // GET /logs/all -> calls GET_ALL_LOGS() which returns OUT_CURSOR
    @GetMapping("/all")
    public String getAllLogs(Model model) {
        Map<String, Object> result = procedureService.callProcedure("GET_ALL_LOGS", Collections.emptyMap());
        List<?> rows = extractRows(result);
        model.addAttribute("rows", rows);
        model.addAttribute("procedureName", "GET_ALL_LOGS");
        return "atm-log";
    }

    // GET /logs/type?type=ATM -> calls GET_LOGS_BY_TYPE(p_type IN)
    @GetMapping("/type")
    public String getLogsByType(@RequestParam String type, Model model) {
        Map<String, Object> params = new HashMap<>();
        params.put("P_TYPE", type);
        Map<String, Object> result = procedureService.callProcedure("GET_LOGS_BY_TYPE", params);
        List<?> rows = extractRows(result);
        model.addAttribute("rows", rows);
        model.addAttribute("procedureName", "GET_LOGS_BY_TYPE");
        return "atm-log";
    }

    // GET /logs/range?from=2026-01-01&to=2026-02-01 -> calls
    // GET_LOGS_BY_RANGE(p_from, p_to)
    @GetMapping("/range")
    public String getLogsByRange(@RequestParam String from, @RequestParam String to, Model model) {
        Map<String, Object> params = new HashMap<>();
        params.put("P_FROM", from);
        params.put("P_TO", to);
        Map<String, Object> result = procedureService.callProcedure("GET_LOGS_BY_RANGE", params);
        List<?> rows = extractRows(result);
        model.addAttribute("rows", rows);
        model.addAttribute("procedureName", "GET_LOGS_BY_RANGE");
        return "atm-log";
    }

    // GET /logs/filter?level=ERROR&source=ATM&region=EU -> calls
    // GET_LOGS_BY_FILTER(p_level, p_source, p_region)
    @GetMapping("/filter")
    public String getLogsByFilter(@RequestParam(required = false) String level,
            @RequestParam(required = false) String source,
            @RequestParam(required = false) String region,
            Model model) {
        Map<String, Object> params = new HashMap<>();
        params.put("P_LEVEL", level);
        params.put("P_SOURCE", source);
        params.put("P_REGION", region);
        Map<String, Object> result = procedureService.callProcedure("GET_LOGS_BY_FILTER", params);
        List<?> rows = extractRows(result);
        model.addAttribute("rows", rows);
        model.addAttribute("procedureName", "GET_LOGS_BY_FILTER");
        return "atm-log";
    }

    // GET /logs/custom with up to 4 parameters
    @GetMapping("/custom")
    public String getLogsCustom(@RequestParam(required = false) String p1,
            @RequestParam(required = false) String p2,
            @RequestParam(required = false) String p3,
            @RequestParam(required = false) String p4,
            Model model) {
        Map<String, Object> params = new HashMap<>();
        if (p1 != null)
            params.put("P1", p1);
        if (p2 != null)
            params.put("P2", p2);
        if (p3 != null)
            params.put("P3", p3);
        if (p4 != null)
            params.put("P4", p4);
        Map<String, Object> result = procedureService.callProcedure("GET_LOGS_CUSTOM", params);
        List<?> rows = extractRows(result);
        model.addAttribute("rows", rows);
        model.addAttribute("procedureName", "GET_LOGS_CUSTOM");
        return "atm-log";
    }

    private List<?> extractRows(Map<String, Object> result) {
        if (result != null && result.containsKey("OUT_CURSOR")) {
            Object o = result.get("OUT_CURSOR");
            if (o instanceof List)
                return (List<?>) o;
        }
        return Collections.emptyList();
    }
}
