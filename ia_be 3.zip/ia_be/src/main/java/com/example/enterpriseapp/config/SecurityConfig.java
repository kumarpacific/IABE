package com.example.enterpriseapp.config;

import com.example.enterpriseapp.security.ApiRequestFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf().disable()
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/css/**", "/js/**", "/images/**", "/login", "/error").permitAll()
                        .anyRequest().authenticated())
                .oauth2Login(); // Azure AD configuration via application.yml

        // register custom filter for request enrichment and security checks
        http.addFilterBefore(new ApiRequestFilter(), org.springframework.web.filter.OncePerRequestFilter.class);

        // security headers
        http.headers(headers -> headers
                .xssProtection().and()
                .contentSecurityPolicy("default-src 'self'"));

        return http.build();
    }
}
