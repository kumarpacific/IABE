package com.example.enterpriseapp.util;

import org.springframework.stereotype.Component;

import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;
import java.util.Locale;

@Component
public class FormatService {
    public String formatValue(Object value, String type) {
        if (value == null)
            return "";
        try {
            switch ((type == null) ? "" : type.toUpperCase()) {
                case "DATE":
                case "TIMESTAMP":
                    if (value instanceof java.sql.Timestamp) {
                        java.time.Instant inst = ((java.sql.Timestamp) value).toInstant();
                        return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
                                .withZone(java.time.ZoneId.systemDefault()).format(inst);
                    }
                    if (value instanceof java.util.Date) {
                        return DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")
                                .withZone(java.time.ZoneId.systemDefault())
                                .format(((java.util.Date) value).toInstant());
                    }
                    return value.toString();
                case "NUMBER":
                case "DECIMAL":
                    NumberFormat nf = NumberFormat.getNumberInstance(Locale.getDefault());
                    if (value instanceof Number)
                        return nf.format(value);
                    return value.toString();
                case "CURRENCY":
                    NumberFormat cf = NumberFormat.getCurrencyInstance(Locale.getDefault());
                    if (value instanceof Number)
                        return cf.format(value);
                    return value.toString();
                case "BOOLEAN":
                    return Boolean.parseBoolean(value.toString()) ? "Yes" : "No";
                default:
                    return value.toString();
            }
        } catch (Exception e) {
            return value.toString();
        }
    }

    public String maskPII(String value) {
        if (value == null)
            return null;
        int len = value.length();
        if (len <= 4)
            return "****";
        return value.substring(0, 2) + "****" + value.substring(len - 2);
    }
}
