package com.example.enterpriseapp.db;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

@Component
public class DatabaseIntrospector {
    private final DataSource dataSource;
    private final JdbcTemplate jdbcTemplate;

    public DatabaseIntrospector(DataSource dataSource, JdbcTemplate jdbcTemplate) {
        this.dataSource = dataSource;
        this.jdbcTemplate = jdbcTemplate;
    }

    /**
     * Return a list of table names available in the current schema
     */
    public List<String> listTables() throws Exception {
        List<String> tables = new ArrayList<>();
        try (Connection conn = dataSource.getConnection()) {
            DatabaseMetaData meta = conn.getMetaData();
            String schema = conn.getSchema();
            try (ResultSet rs = meta.getTables(conn.getCatalog(), schema, "%", new String[] { "TABLE" })) {
                while (rs.next()) {
                    String table = rs.getString("TABLE_NAME");
                    tables.add(table);
                }
            }
        }
        return tables;
    }

    /**
     * Return column names for a given table
     */
    public List<String> getTableColumns(String table) throws Exception {
        List<String> cols = new ArrayList<>();
        try (Connection conn = dataSource.getConnection()) {
            DatabaseMetaData meta = conn.getMetaData();
            String schema = conn.getSchema();
            try (ResultSet rs = meta.getColumns(conn.getCatalog(), schema, table, "%")) {
                while (rs.next()) {
                    cols.add(rs.getString("COLUMN_NAME"));
                }
            }
        }
        return cols;
    }

    /**
     * Return column metadata: ordered map column -> data type name
     */
    public Map<String, String> getTableColumnTypes(String table) throws Exception {
        Map<String, String> cols = new LinkedHashMap<>();
        try (Connection conn = dataSource.getConnection()) {
            DatabaseMetaData meta = conn.getMetaData();
            String schema = conn.getSchema();
            try (ResultSet rs = meta.getColumns(conn.getCatalog(), schema, table, "%")) {
                while (rs.next()) {
                    cols.put(rs.getString("COLUMN_NAME"), rs.getString("TYPE_NAME"));
                }
            }
        }
        return cols;
    }

    /**
     * Safely return rows for a table limited to `limit` rows. Validates table
     * exists.
     */
    public List<Map<String, Object>> getTableRows(String table, int limit) throws Exception {
        // validate table in list
        Set<String> allowed = new HashSet<>(listTables());
        if (!allowed.contains(table)) {
            throw new IllegalArgumentException("Table not found: " + table);
        }

        // For Oracle, use ROWNUM for limit
        String sql = "SELECT * FROM " + table + " WHERE ROWNUM <= ?";
        return jdbcTemplate.queryForList(sql, limit);
    }

    /**
     * Paged query with a simple ORDER BY column (if provided). Uses rownum
     * pagination for Oracle.
     */
    public List<Map<String, Object>> getTableRowsPaged(String table, int offset, int limit, String orderBy, boolean asc)
            throws Exception {
        Set<String> allowed = new HashSet<>(listTables());
        if (!allowed.contains(table)) {
            throw new IllegalArgumentException("Table not found: " + table);
        }

        // If no orderBy provided, fallback to ROWNUM order
        String order = "";
        if (orderBy != null && !orderBy.isBlank()) {
            // validate orderBy column exists
            var cols = getTableColumns(table);
            if (!cols.contains(orderBy)) {
                throw new IllegalArgumentException("Invalid orderBy column: " + orderBy);
            }
            order = " ORDER BY " + orderBy + (asc ? " ASC" : " DESC");
        }

        // For large tables prefer keyset (seek) pagination when orderBy provided
        if (orderBy != null && !orderBy.isBlank() && offset == 0) {
            // initial page
            String sql = "SELECT * FROM " + table + order + " FETCH FIRST ? ROWS ONLY";
            return jdbcTemplate.queryForList(sql, limit);
        } else if (orderBy != null && !orderBy.isBlank()) {
            // keyset-like: use where clause to skip rows > last seen value — but we need
            // lastSeen param. As an approximation
            // use offset+limit nested ROWNUM approach
            String sql = "SELECT * FROM (SELECT a.*, ROWNUM rnum FROM (SELECT * FROM " + table + order + ") a "
                    + "WHERE ROWNUM <= ? ) WHERE rnum > ?";
            return jdbcTemplate.queryForList(sql, offset + limit, offset);
        } else {
            // fallback to simple ROWNUM limit
            String sql = "SELECT * FROM " + table + " WHERE ROWNUM <= ?";
            return jdbcTemplate.queryForList(sql, limit);
        }
    }

    /**
     * Keyset pagination helper: fetch page after the given lastValue for orderBy
     * column.
     * This method assumes lastValue is a single column value and orderBy is
     * provided.
     */
    public List<Map<String, Object>> getTableRowsAfter(String table, String orderBy, Object lastValue, int limit,
            boolean asc)
            throws Exception {
        Set<String> allowed = new HashSet<>(listTables());
        if (!allowed.contains(table)) {
            throw new IllegalArgumentException("Table not found: " + table);
        }
        var cols = getTableColumns(table);
        if (!cols.contains(orderBy)) {
            throw new IllegalArgumentException("Invalid orderBy column: " + orderBy);
        }

        String cmp = asc ? ">" : "<";
        String sql = "SELECT * FROM " + table + " WHERE " + orderBy + " " + cmp + " ? ORDER BY " + orderBy
                + (asc ? " ASC" : " DESC") + " FETCH FIRST ? ROWS ONLY";
        return jdbcTemplate.queryForList(sql, lastValue, limit);
    }
}
