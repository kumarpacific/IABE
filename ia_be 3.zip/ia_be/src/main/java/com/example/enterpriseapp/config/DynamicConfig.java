package com.example.enterpriseapp.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

import java.util.ArrayList;
import java.util.List;

@Configuration
@ConfigurationProperties(prefix = "app.dynamic")
public class DynamicConfig {
    /**
     * Comma-separated list of columns to hide globally (case-insensitive)
     */
    private List<String> hiddenColumns = new ArrayList<>();
    private List<String> maskedColumns = new ArrayList<>();
    /**
     * Map of column name -> allowed roles
     */
    private java.util.Map<String, List<String>> columnPermissions = new java.util.HashMap<>();

    public List<String> getHiddenColumns() {
        return hiddenColumns;
    }

    public void setHiddenColumns(List<String> hiddenColumns) {
        this.hiddenColumns = hiddenColumns;
    }

    public List<String> getMaskedColumns() {
        return maskedColumns;
    }

    public void setMaskedColumns(List<String> maskedColumns) {
        this.maskedColumns = maskedColumns;
    }

    public java.util.Map<String, List<String>> getColumnPermissions() {
        return columnPermissions;
    }

    public void setColumnPermissions(java.util.Map<String, List<String>> columnPermissions) {
        this.columnPermissions = columnPermissions;
    }
}
