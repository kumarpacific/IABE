package com.example.enterpriseapp.service;

import com.example.enterpriseapp.db.StoredProcedureExecutor;
import org.springframework.stereotype.Service;

import javax.sql.DataSource;
import java.util.Map;

@Service
public class ProcedureService {
    private final StoredProcedureExecutor executor;

    public ProcedureService(DataSource dataSource) {
        this.executor = new StoredProcedureExecutor(dataSource);
    }

    public Map<String, Object> callProcedure(String name, Map<String, Object> params) {
        return executor.execute(name, params);
    }
}
