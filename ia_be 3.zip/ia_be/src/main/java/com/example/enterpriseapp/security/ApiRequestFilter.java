package com.example.enterpriseapp.security;

import com.example.enterpriseapp.util.CryptoUtil;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.Collections;

public class ApiRequestFilter extends OncePerRequestFilter {
    private static final Logger logger = LogManager.getLogger(ApiRequestFilter.class);

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
            throws ServletException, IOException {
        // Enrich request with correlation id if absent
        String correlationId = request.getHeader("X-Correlation-Id");
        if (correlationId == null || correlationId.isBlank()) {
            correlationId = java.util.UUID.randomUUID().toString();
        }
        response.setHeader("X-Correlation-Id", correlationId);

        // ISD check - placeholder: validate signature header
        String isdSignature = request.getHeader("X-ISD-Signature");
        if (isdSignature == null || !validateIsd(request, isdSignature)) {
            logger.warn("ISD validation failed for correlationId={}", correlationId);
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.getWriter().write("ISD validation failed");
            return;
        }

        // Decrypt body if necessary (assume encoded payloads are sent with header
        // X-Encoded: true)
        String encoded = request.getHeader("X-Encoded");
        if ("true".equalsIgnoreCase(encoded)) {
            // In this skeleton we don't rewrap the HttpServletRequest; production should
            // replace InputStream
            logger.debug("Request payload is encoded; server will decode centrally before processing");
        }

        // Add security headers
        response.setHeader("X-Content-Type-Options", "nosniff");
        response.setHeader("X-Frame-Options", "DENY");
        response.setHeader("Referrer-Policy", "no-referrer");

        filterChain.doFilter(request, response);
    }

    private boolean validateIsd(HttpServletRequest request, String signature) {
        try {
            // Example: compute HMAC of path+query and compare. Key should be in secure
            // config
            String payload = request.getMethod() + "|" + request.getRequestURI() + "|"
                    + (request.getQueryString() == null ? "" : request.getQueryString());
            String key = System.getenv().getOrDefault("ISD_SHARED_KEY", "default_test_key_change_me");
            String expected = CryptoUtil.hmacSha256Base64(payload, key);
            return expected.equals(signature);
        } catch (Exception e) {
            logger.error("Error validating ISD signature", e);
            return false;
        }
    }
}
