package com.example.enterpriseapp.controller;

import com.example.enterpriseapp.service.ProcedureService;
import com.example.enterpriseapp.util.CryptoUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.StreamUtils;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import jakarta.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;
import java.util.Collections;
import java.util.List;
import java.util.Map;

@Controller
public class ProcedureController {
    private static final Logger logger = LogManager.getLogger(ProcedureController.class);
    private final ProcedureService procedureService;

    public ProcedureController(ProcedureService procedureService) {
        this.procedureService = procedureService;
    }

    @RequestMapping("/")
    public String index() {
        return "index";
    }

    @PostMapping(path = "/callProcedure")
    public String callProcedure(HttpServletRequest request, Model model, @RequestParam String name) throws Exception {
        // read body
        String body = StreamUtils.copyToString(request.getInputStream(), StandardCharsets.UTF_8);

        // if header X-Encoded true then decode centrally
        String encoded = request.getHeader("X-Encoded");
        if ("true".equalsIgnoreCase(encoded)) {
            String key = System.getenv().getOrDefault("APP_ENC_KEY_BASE64", "AAAAAAAAAAAAAAAAAAAAAA==");
            body = CryptoUtil.decryptAesGcm(body, key);
        }

        // assume payload is JSON map of parameters
        com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
        Map<String, Object> params = mapper.readValue(body == null || body.isBlank() ? "{}" : body, Map.class);

        Map<String, Object> result = procedureService.callProcedure(name, params);

        // try to extract OUT_CURSOR rows
        List<?> rows = Collections.emptyList();
        if (result != null && result.containsKey("OUT_CURSOR")) {
            Object o = result.get("OUT_CURSOR");
            if (o instanceof List)
                rows = (List<?>) o;
        }

        model.addAttribute("rows", rows);
        model.addAttribute("procedureName", name);
        return "atm-log";
    }
}
