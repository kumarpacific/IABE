package com.example.enterpriseapp.controller;

import com.example.enterpriseapp.config.DynamicConfig;
import com.example.enterpriseapp.db.DatabaseIntrospector;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.bind.annotation.ResponseBody;

import com.example.enterpriseapp.util.FormatService;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Controller
@RequestMapping("/data")
public class GenericDataController {
    private final DatabaseIntrospector introspector;
    private final DynamicConfig dynamicConfig;
    private final FormatService formatService;

    public GenericDataController(DatabaseIntrospector introspector, DynamicConfig dynamicConfig,
            FormatService formatService) {
        this.introspector = introspector;
        this.dynamicConfig = dynamicConfig;
        this.formatService = formatService;
    }

    @GetMapping("/tables")
    public String listTables(Model model) throws Exception {
        List<String> tables = introspector.listTables();
        model.addAttribute("tables", tables);
        return "tables";
    }

    @GetMapping("/table/{name}")
    public String viewTable(@PathVariable("name") String name,
            @RequestParam(name = "limit", required = false, defaultValue = "100") int limit,
            @RequestParam(name = "offset", required = false, defaultValue = "0") int offset,
            @RequestParam(name = "orderBy", required = false) String orderBy,
            @RequestParam(name = "asc", required = false, defaultValue = "false") boolean asc,
            Model model) throws Exception {
        // columns with types
        var colTypes = introspector.getTableColumnTypes(name);

        // apply hidden columns filter from config
        var hidden = dynamicConfig.getHiddenColumns();
        colTypes.keySet().removeIf(c -> hidden.stream().anyMatch(h -> h.equalsIgnoreCase(c)));

        // apply column-level permissions
        var columnPerms = dynamicConfig.getColumnPermissions();
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        var roles = auth == null ? new ArrayList<String>()
                : auth.getAuthorities().stream().map(a -> a.getAuthority()).collect(Collectors.toList());

        List<String> visibleColumns = new ArrayList<>();
        for (String col : colTypes.keySet()) {
            if (columnPerms.containsKey(col)) {
                var allowed = columnPerms.get(col);
                boolean ok = allowed.stream().anyMatch(r -> roles.contains(r));
                if (ok)
                    visibleColumns.add(col);
            } else {
                visibleColumns.add(col);
            }
        }

        List<Map<String, Object>> rows = introspector.getTableRowsPaged(name, offset, limit, orderBy, asc);
        model.addAttribute("tableName", name);
        model.addAttribute("columns", visibleColumns);
        model.addAttribute("colTypes", colTypes);
        model.addAttribute("rows", rows);
        model.addAttribute("offset", offset);
        model.addAttribute("limit", limit);
        model.addAttribute("orderBy", orderBy);
        model.addAttribute("asc", asc);
        model.addAttribute("maskedColumns", dynamicConfig.getMaskedColumns());
        model.addAttribute("offset", offset);
        model.addAttribute("limit", limit);
        model.addAttribute("orderBy", orderBy);
        model.addAttribute("asc", asc);
        return "dynamic-table";
    }

    // JSON API for programmatic access
    @GetMapping(path = "/table/{name}/json", produces = "application/json")
    @ResponseBody
    public List<Map<String, Object>> viewTableJson(@PathVariable("name") String name,
            @RequestParam(name = "limit", required = false, defaultValue = "100") int limit,
            @RequestParam(name = "offset", required = false, defaultValue = "0") int offset,
            @RequestParam(name = "orderBy", required = false) String orderBy,
            @RequestParam(name = "asc", required = false, defaultValue = "false") boolean asc) throws Exception {
        List<Map<String, Object>> rows = introspector.getTableRowsPaged(name, offset, limit, orderBy, asc);
        return rows;
    }

    // Keyset (seek) pagination JSON endpoint: supply orderBy, lastValue and limit
    @GetMapping(path = "/table/{name}/keyset", produces = "application/json")
    @ResponseBody
    public List<Map<String, Object>> viewTableKeyset(@PathVariable("name") String name,
            @RequestParam(name = "orderBy") String orderBy,
            @RequestParam(name = "lastValue") String lastValue,
            @RequestParam(name = "limit", required = false, defaultValue = "100") int limit,
            @RequestParam(name = "asc", required = false, defaultValue = "false") boolean asc) throws Exception {
        // lastValue passed as string; the introspector will use it as bind parameter
        return introspector.getTableRowsAfter(name, orderBy, lastValue, limit, asc);
    }
}
