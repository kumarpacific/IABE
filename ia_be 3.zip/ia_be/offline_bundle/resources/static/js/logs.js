document.addEventListener('DOMContentLoaded', function () {
  const btn = document.getElementById('fetch-logs');
  if (!btn) return;

  btn.addEventListener('click', function (e) {
    e.preventDefault();
    fetch('/logs/all')
      .then(r => r.text())
      .then(html => {
        // replace the content area with response HTML
        const container = document.getElementById('content');
        if (container) container.innerHTML = html;
      })
      .catch(err => console.error('Error fetching logs', err));
  });
});
