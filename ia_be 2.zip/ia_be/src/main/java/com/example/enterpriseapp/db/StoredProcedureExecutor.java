package com.example.enterpriseapp.db;

import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.simple.SimpleJdbcCall;
import org.springframework.jdbc.core.SqlReturnResultSet;

import javax.sql.DataSource;
import java.util.HashMap;
import java.util.Map;

public class StoredProcedureExecutor {
    private final JdbcTemplate jdbcTemplate;

    public StoredProcedureExecutor(DataSource dataSource) {
        this.jdbcTemplate = new JdbcTemplate(dataSource);
    }

    /**
     * Execute a stored procedure by name.
     * payload map contains IN parameters.
     * Returns map of out parameters or result sets.
     */
    public Map<String, Object> execute(String procedureName, Map<String, Object> payload) throws DataAccessException {
        SimpleJdbcCall call = new SimpleJdbcCall(jdbcTemplate).withProcedureName(procedureName);

        // naive: assume single REF CURSOR out param named "OUT_CURSOR" if needed
        call.declareParameters(new SqlReturnResultSet("OUT_CURSOR", (rs, rowNum) -> {
            // convert row to map
            java.util.Map<String, Object> row = new java.util.HashMap<>();
            int cols = rs.getMetaData().getColumnCount();
            for (int i = 1; i <= cols; i++) {
                row.put(rs.getMetaData().getColumnLabel(i), rs.getObject(i));
            }
            return row;
        }));

        Map<String, Object> inParams = new HashMap<>();
        if (payload != null)
            inParams.putAll(payload);

        Map<String, Object> result = call.execute(inParams);
        return result;
    }
}
