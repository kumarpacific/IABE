Static assets for the web app - place JS, CSS and images here.

- `js/` - client-side JavaScript
- `css/` - stylesheets
- `images/` - static images

These folders contain `.gitkeep` files to ensure they are tracked in git; replace them with real assets.
